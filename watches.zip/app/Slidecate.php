<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Slidecate extends Model
{
    protected $table ='slidecate';

}
