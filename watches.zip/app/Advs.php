<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Advs extends Model
{
    protected $table ='advs';

}
