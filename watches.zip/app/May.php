<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class May extends Model
{
    protected $table ='kieumay';

}
