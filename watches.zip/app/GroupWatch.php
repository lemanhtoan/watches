<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GroupWatch extends Model
{
    protected $table ='group_watch';

}
