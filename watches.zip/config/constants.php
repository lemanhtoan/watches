<?php
return [
    'khoanggia' => [
        '0' => 'Tất cả khoảng giá',
        '1' => 'Dưới 2 triệu',
        '2' => 'Từ 2 triệu - 4 triệu',
        '4' => 'Từ 4 triệu - 6 triệu',
        '6' => 'Từ 6 triệu - 9 triệu',
        '15x' => 'Trên 15 triệu',
    ],
    'sapxep' => [
        'priceDesc' => 'Giá giảm dần',
        'priceAsc' => 'Giá tăng dần',
        'nameAz' => 'Tên sản phẩm ( từ A đến Z )',
        'nameZa' => 'Tên sản phẩm ( từ Z đến A )',
    ]
];
?>
